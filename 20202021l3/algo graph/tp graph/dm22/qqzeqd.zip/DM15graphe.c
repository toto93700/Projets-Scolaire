#include "graph_mat-2.h"
#include "graph_mat-2.c"
#include "liste.h"


#include <stdlib.h>
#include <stdio.h>






void parcoursProfondeur(graph_mat *graph){
int w=0;
int *c;
int boul=1;



liste * mylist=liste_construire(graph->n);


liste * mylist2=liste_construire(graph->n);

liste *mylist3=liste_construire(graph->n);


liste_ajouter_debut(mylist,0);






        while(liste_est_vide(mylist)==0){

            int k=*(liste_get_fin(mylist));

             for(w=0; w<(graph->n);w++){
                     printf(" \n %d",w);
               if(liste_contient_element(mylist,w)==0 && liste_contient_element(mylist2,w)==0){
                    printf("\n  %d n'est ni dans l1 ni dans l2",w);
                if((int)gm_mult_edge(graph,k,w)>0){
                     printf(" \n  oui il existe un lien entre %d %w",k,w);

                    liste_ajouter_fin(mylist,w);

                    printf(" \n la fin de ma list est %d",w);
                    w=100;
                    printf(" \n on quite w=  %d",w);
                }
               }

              }

              k=*liste_get_fin(mylist);
                 printf(" \n ma fin de liste est %d",k);

              boul=1;

              for(int l=0;l<(graph->n);l++){

                if(gm_mult_edge(graph,k,l)>0){
                    printf("\n  il existe un lien entre %d et  %d ",k,l);

                  if(liste_contient_element(mylist,l)==0 && liste_contient_element(mylist2,l)==0){
                      printf("\n  %d n'est ni dans l1 ni l2  donc boul=0",l);
                      boul=0;
                      break;
                 }
                }
              }
              if(boul==1){

                liste_ajouter_fin(mylist2,k);
                liste_supprimer_fin(mylist,c);
              }
            }

             liste_afficher(mylist2);
        }







